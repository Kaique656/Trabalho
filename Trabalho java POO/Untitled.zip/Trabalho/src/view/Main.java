package view;

import javax.swing.JOptionPane;

import Armazenar.Armazenar;

public class Main {
	
	
	private Armazenar a;
	
	public Main() {
		
		boolean continuar =true;
		
		while (continuar) {
			
			String nomeArquivo  = JOptionPane.showInputDialog("Crie ou acesse o aqruivo que voce deseja colocar ");
			
			a.addArquivo(noem);
			
		}
		
	}
	
	public static void main(String[]args) {
		new Main();
	}
}
